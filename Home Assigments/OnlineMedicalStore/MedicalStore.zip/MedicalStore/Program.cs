﻿using System;
using MedicalStore;
class Program
{
    public static void Main(string[] args)
    {
        //FileHandling.Create();
        Operations.AddingData();
       Operations.Mainmenu();
    }
}