﻿using System;

namespace MultiLevelInheritance;
class Program
{
    public static void Main(string[] args)
    {
        
        StudentInfo.ShowInfo();
        System.Console.WriteLine($"RegisterNumber:{student1.RegisterNumber}"); 
        

    }
}