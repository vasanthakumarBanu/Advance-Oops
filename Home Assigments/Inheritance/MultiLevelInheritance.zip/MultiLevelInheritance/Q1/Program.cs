﻿using System;
using Q1;
class Program
{
    public static void Main(string[] args)
    {
        
       
    
 }
}