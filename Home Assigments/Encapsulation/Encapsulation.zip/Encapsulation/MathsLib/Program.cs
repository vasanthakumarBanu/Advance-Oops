﻿using System;
namespace MathsLIb;
class Program
{
    public static void Main(string[] args)
    {
        
    }
}