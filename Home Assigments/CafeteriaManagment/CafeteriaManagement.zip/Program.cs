﻿using System;
using CafeteriaManagment;
class Program
{
    public static void Main(string[] args)
    {
        Operations.AddingDefault();
        Operations.MainMenu();
    }
}