// using System;
// using System.Collections;
// using System.Linq;
// using System.Threading.Tasks;

// namespace List
// {
//     public partial class CustomList<Type>:IEnumerable,IEnumerator
//     {
//         int position;
//         public iEnumerator GetEnumerator()
//         { position = -1;
//             return(IEnumerator)this;
//         }
//         public bool MoveNext()
//         {
//             if(position<_count-1)
//             {
//                 position++;
//                 
//            
//         }
//     }
// }