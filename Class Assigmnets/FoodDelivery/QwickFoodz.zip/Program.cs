﻿using System;
using QwickFoodz;

class Program
{
    public static void Main(string[] args)
    {
        Operations.AddingData();
        Operations.MainMenu();
    }
}