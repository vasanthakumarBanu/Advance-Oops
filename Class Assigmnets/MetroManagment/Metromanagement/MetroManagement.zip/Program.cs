﻿using System;
using Metromanagement;
class Program
{
    public static void Main(string[] args)
    {
        //Operations.AddingData();
        //FileHandling.Create();
        FileHandling.WriteToCVS();
        FileHandling.ReadFromCSV();
        Operations.MainMenu();
        
    }
}